package com.crossover.e2e;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class GMailTest {
    private WebDriver driver;
    private Properties properties = new Properties();

@BeforeTest  
 public void setUp() throws InterruptedException, FileNotFoundException, IOException {
        
 properties.load(new FileReader(new File("G:\\qa-automation-selenium-java\\src\\test\\resources\\test.properties")));
  
      //Dont Change below line. Set this value in test.properties file incase you need to change it..
       
 System.setProperty("webdriver.chrome.driver",properties.getProperty("webdriver.chrome.driver") );
   
     driver = new ChromeDriver();
     driver.get("https://mail.google.com/");
     driver.manage().window().maximize();
   
 }

 @AfterTest
 public void tearDown() throws Exception {
        driver.quit();
    }

  
  /*
     * Please focus on completing the task
     * 
     */
   
 @Test
   
 public void testSendEmail() throws InterruptedException {
       //email id
    WebElement userElement = driver.findElement(By.id("identifierId"));
    
    userElement.sendKeys(String.format("%s@gmail.com",properties.getProperty("username")));

    driver.findElement(By.id("identifierNext")).click();
    
    //password
  
    WebDriverWait wait = new WebDriverWait(driver, 20);
    wait.until(ExpectedConditions.presenceOfElementLocated(By.name("password"))); 
      
    WebElement passwordElement = driver.findElement(By.name("password"));
    
    passwordElement.sendKeys(properties.getProperty("password"));
       //send
    driver.findElement(By.id("passwordNext")).click();

    Thread.sleep(3000);

    WebDriverWait wait2 = new WebDriverWait(driver,30);
    wait2.until(ExpectedConditions.visibilityOfElementLocated(By.className("z0")));
    //click on the compose button when it is visible
    driver.findElement(By.className("z0")).click();
 
    WebDriverWait wait1 = new WebDriverWait(driver, 30);
    wait1.until(ExpectedConditions.presenceOfElementLocated(By.name("to")));
    driver.findElement(By.name("to")).clear();
    driver.findElement(By.name("to")).sendKeys(String.format("%s@gmail.com",properties.getProperty("username")));
 
    // emailSubject and emailbody to be used in this unit test.
    
   WebDriverWait wait3 = new WebDriverWait(driver, 30);
   wait3.until(ExpectedConditions.presenceOfElementLocated(By.className("aoT"))); 
   String emailSubject = properties.getProperty("email.subject");
   driver.findElement(By.className("aoT")).sendKeys(emailSubject);
    
   //email body
   String emailBody = properties.getProperty("email.body"); 
   driver.findElement(By.className("Am")).sendKeys(emailBody);
   driver.findElement(By.className("Am")).click();
   
   //click on more options then selecting social label
   WebDriverWait wait4 = new WebDriverWait(driver, 30);
   wait4.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@data-tooltip='More options']")));
   driver.findElement(By.xpath("//div[@data-tooltip='More options']")).click();
   driver.findElement(By.xpath("//div[text()='Label']")).click();
   driver.findElement(By.xpath("//input[@ignoreesc='true']")).sendKeys("social");
   driver.findElement(By.xpath("//input[@ignoreesc='true']")).sendKeys(Keys.ENTER);

   //click send button
   driver.findElement(By.xpath("//*[@role='button' and text()='Send']")).click();
   //click inbox
   WebDriverWait wait5 = new WebDriverWait(driver, 30);
   wait5.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[text()='Inbox']")));
   driver.findElement(By.xpath("//a[text()='Inbox']")).click();
 
   Thread.sleep(3000);
  //find new mail ,click starred open mail
   List<WebElement> unreademail = driver.findElements(By.className("zE"));

   System.out.println("Total No. of Unread Mails: " + unreademail.size());

   for(int i=0;i<unreademail.size();i++){
   System.out.println(unreademail.get(i).getText());
   unreademail.get(0).findElement(By.xpath("//span[@title='Not starred']")).click();
   unreademail.get(0).click();
   Thread.sleep(3000);

   //verify social label
   String label= "Social";
   String label2=driver.findElement(By.name("^smartlabel_social")).getText();
   //assertEquals(label,label2);
   if(label.equals(label2))
	System.out.println("passed label");
   else
	System.out.println("case failed label");
   Thread.sleep(3000);

   //verifying subject
   String subject=driver.findElement(By.className("hP")).getText();
   //assertEquals(emailSubject,subject);
   if(subject.equals(emailSubject))
	System.out.println("passed subject");
   else
	System.out.println("case failed subject");
  
   //verifying mail body
   String body=driver.findElement(By.cssSelector(".ii.gt")).getText();
   if(body.equals(emailBody))
	System.out.println("case body passed");
   else
	System.out.println("case failed");

  }
 }
}
    
   